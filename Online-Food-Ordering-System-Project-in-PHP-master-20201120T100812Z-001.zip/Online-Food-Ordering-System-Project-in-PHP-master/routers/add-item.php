<?php
include '../includes/connect.php';

$name = $_POST['name'];
$price = $_POST['price'];
$sql = "INSERT INTO order_items (name, price) VALUES ('$name', $price)";
$con->query($sql);
header("location: ../admin-page.php");
?>